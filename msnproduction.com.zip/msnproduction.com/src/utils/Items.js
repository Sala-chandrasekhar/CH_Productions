import { FaCheck } from "react-icons/fa";

const Items = [
  {
    id: 1,
    title: "SIP",
    subtitle: "(Standar)",
    label: "₹",
    price: "13.9K",
    diskon: "24.0K",
    icon: <FaCheck />,
    description:
      "GOLD & PREMIUM Theme Design \n Active Period 6 months \n Max Revision. 5 points \n Unlimited Share \n Countdown \n Quotes / Verse Quotes \n Directional Buttons \n Custom Guest Name \n Free Music Request \n Auto-play Music \n Health Protocol Std. \n Menu Button \n WhatsApp Greetings \n Photos in Gallery (Max. 5)",
    category: "wedding",
  },
  {
    id: 2,
    title: "BASIC",
    subtitle: "(Standard)",
    label: "₹",
    price: "19.9K",
    diskon: "32.9K",
    icon: <FaCheck />,
    description:
      "GOLD & PREMIUM Theme Design \n Active Period 12 months \n Max Revision. 10 points \n Unlimited Share \n Countdown \n Quotes / Verse Quotes \n Directional Buttons \n Custom Guest Name \n Free Music Request \n Auto-play Music \n Health Protocol Std. \n Menu Button \n Wish Box Greeting \n Photos in Gallery (Max. 8) \n Video in Gallery/Love Story (Max. 1) \n Google Maps Map \n Live Streaming Link \n Save to Google Calendar \n RSVP - Confirmation of Attendance \n Digital Envelope (Max. 3 Accounts)",
    category: "wedding",
  },
  {
    id: 3,
    title: "ADVANCE",
    subtitle: "(Full Standard)",
    label: "₹",
    price: "24.9K",
    diskon: "49.9K",
    icon: <FaCheck />,
    description:
      "GOLD & PREMIUM Theme Design \n Active Period 12 months \n UNLIMITED Revisions \n Unlimited Share \n Countdown \n Quotes / Paragraph Quotes \n Directional Buttons \n Custom Guest Name \n Free Music Request \n Auto-play Music \n Health Protocol Std. \n Wish Box Greeting Menu Button Photos in Gallery (Max. 12) \n Videos in Gallery/Love Story (Max. 2) \n Google Maps Map \n Live Streaming Link \n Save to Google Calendar \n RSVP - Confirm Attendance \n Digital Envelope (Max. 3 Accounts) \n Love Story (Max. 5 Timelines)",
    category: "wedding",
  },
  {
    id: 4,
    title: "PRO",
    subtitle: "(Full Standard, Photo & Video Preview)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "GOLD & PREMIUM Theme Design \n Active Period 12 months \n UNLIMITED Revisions \n Unlimited Share \n Countdown \n Quotes / Paragraph Quotes \n Directional Buttons \n Custom Guest Name \n Free Music Request \n Auto-play Music \n Health Protocol Std. \n Menu Button \n Wish Box Greeting \n Photos in Gallery (Max. 12) \n Videos in Gallery/Love Story (Max. 2) \n Google Maps Map \n Live Streaming Link \n Save to Google Calendar \n RSVP - Attendance Confirmation \n Digital Envelope (Max. 3 Accounts) \n Love Story (Max. 5 Timelines) \n Pre-Wed Photographer \n Wedding Photographer \n Cinematic Video",
    category: "wedding",
  },
  {
    id: 5,
    title: "PAKET STARTER",
    subtitle: "(Standard)",
    label: "₹",
    price: "19.99K",
    diskon: "26.99K",
    icon: <FaCheck />,
    description:
      "Domain .com \n SSL Certificate \n 1GB Capacity (Shared Hosting) \n 1 Professional Email \n 10+ Selected Themes \n Access to Admin Dashboard \n Product Management Features \n Order Management Features (via cart / whatsapp) \n Promotion Management Features \n Payment Management Features (Manual Bank Transfer) \n Delivery Management Features (JNE, POS, TIKI, J&T, Sicepat, etc.) \n 2x Design Revisions \n Documentation & Video Tutorial \n Free Website Use Training \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee*",
    category: "online store",
  },
  {
    id: 6,
    title: "PAKET UMKM",
    subtitle: "(Standard)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "Domain .com \n SSL Certificate \n 10GB Capacity (Private Hosting) \n 10 Professional Emails \n Request Website Design \n Access to Admin Dashboard \n Access to Cpanel \n Product Management Features \n Order Management Features (via cart / whatsapp) \n Promotion Management Feature \n Payment Management Feature (Manual bank transfer) \n Delivery Management Feature (JNE, POS, TIKI, J&T, Sicepat, etc.) \n 3x Revision Design \n Documentation & Video Tutorials \n Free Website Use Training \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee*",
    category: "online store",
  },
  {
    id: 7,
    title: "PAKET CORPORATE",
    subtitle: "(Full Standard)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "Domain .com / .id / .co.id \n SSL Certificate \n 40GB Capacity (Private Hosting) \n 30+ Professional Emails \n Request Website Design \n 20+ Website Pages \n Access to Admin Dashboard \n Access to Cpanel \n Product Management Feature \n Order Management Feature (via cart / whatsapp) \n Promotion Management Feature \n Payment Management Feature (Manual bank transfer) \n Delivery Management Feature (JNE, POS, TIKI, J&T, Sicepat, etc.) \n 5x Design Revisions \n Documentation & Video Tutorials \n Free Website Use Training \n On Page SEO Optimization, Google Webmaster Integration, Google Analytics, & Facebook Pixel \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee*",
    category: "online store",
  },
  {
    id: 8,
    title: "PAKET CORPORATE",
    subtitle: "(Full Standard)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "Domain .com / .id / .co.id \n SSL Certificate \n 40GB Capacity (Private Hosting) \n 30+ Professional Emails \n Request Website Design \n 20+ Website Pages \n Access to Admin Dashboard \n Access to Cpanel \n Product Management Feature \n Order Management Feature (via basket / WhatsApp) \n Promotion Management Feature \n Payment Management Feature (Integration with payment gateway) \n Delivery Management Feature (JNE, POS, TIKI, J&T, Sicepat, etc.) \n Order Invoice & Delivery Slip Feature \n Social Media Integration (Facebook Catalogue, Instagram Shop) \n Social media authentication (Facebook & Gmail Login Register) \n Sales Popup \n Order Notification (Email/SMS/Whatsapp) \n Progressive Web App (Mobile Application) \n 5x Design Revision \n Documentation & Video Tutorial \n Free Website Use Training \n Optimization SEO on Page, Google Webmaster Integration, Google Analytics, & Facebook Pixel \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee*",
    category: "online store",
  },
  {
    id: 9,
    title: "PAKET STARTER",
    subtitle: "(Ideal Ultra Premium)",
    label: "₹",
    price: "99K",
    diskon: "149.9K",
    icon: <FaCheck />,
    description:
      "Domain .com \n 1GB Capacity (Shared Hosting) \n 1 Professional Email \n 10+ Selected Themes \n 8 Website Pages \n Full Admin Access \n 2x Design Revisions \n Free Video Tutorials & Training \n Free Optimization & Consultation Digital Marketing \n Lifetime Guarantee*",
    category: "companyprofile",
  },
  {
    id: 10,
    title: "PAKET UMKM",
    subtitle: "(Ideal Ultra Mega)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "Domain .com \n SSL Certificate \n 10GB Capacity (Private Hosting) \n 10 Professional Emails \n Request Website Design \n 8-20 Page Website \n Full Admin & cPanel Access \n 3x Design Revision \n Free Video Tutorial & Training \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee*",
    category: "companyprofile",
  },
  {
    id: 11,
    title: "PAKET CORPORATE",
    subtitle: "(Ideal Ultra Mega Premium)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "Domain .com / .id / .co.id \n SSL Certificate \n 40GB Capacity (Private Hosting) \n 30+ Professional Emails \n Request Website Design \n 20+ Website Pages \n Full Admin & cPanel Access \n 5x Design Revisions \n Free Video Tutorials & Training \n On Page SEO Optimization, Google Webmaster Integration, Google Analytics, & Facebook Pixel \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee Life*",
    category: "companyprofile",
  },
  {
    id: 12,
    title: "PAKET CORPORATE",
    subtitle: "(Ideal Ultra Mega Premium)",
    price: "CALL US",
    diskon: "x.xxxK",
    icon: <FaCheck />,
    description:
      "Domain .com / .id / .co.id \n SSL Certificate \n 40GB Capacity (Private Hosting) \n 30+ Professional Emails \n Request Website Design \n 20+ Website Pages \n Full Admin & cPanel Access \n 5x Design Revision \n Social media authentication (Facebook & Gmail Login Register) \n Sales Popup \n Notification (Email/SMS/Whatsapp) \n Progressive Web App (Mobile Application) \n Free Video Tutorial & Training \n On Page SEO optimization, Google Webmaster Integration, Google Analytics, & Facebook Pixel \n Free Optimization & Digital Marketing Consultation \n Lifetime Guarantee*",
    category: "companyprofile",
    price: "CALL US",
    diskon: "x.xxxK",
  },
];

export default Items;
