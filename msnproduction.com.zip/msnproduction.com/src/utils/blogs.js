const blogs = [
  {
    _id: 1,
    title: "5 Ways to Optimize Instagram SEO, Increase Your Account Visibility",
    path: "optimasi-seo-instagram",
    date: "10 September 2023",
    img: "https://res.cloudinary.com/dh6s3dche/image/upload/v1680151015/Blog%20MSN/01-5_Cara_Optimasi_SEO_Instagram_Tingkatkan_Visibilitas_Akun_Mu_e0acku.jpg",
    tags: ["instagram", "seo", "optimasi", "teknologi"],
    description:
      "Instagram is one of the largest social media platforms in the world. With more than one billion active users every month, Instagram provides a huge opportunity for businesses and individuals to promote their brands and reach a wider audience.",
  },
  {
    _id: 2,
    title: "5 Job Prospects for Informatics Engineering Majors",
    path: "pekerjaan-jurusan-teknik-informatika",
    date: "20 September 2023",
    img: "https://res.cloudinary.com/dh6s3dche/image/upload/v1680154547/Blog%20MSN/5_Prospek_Pekerjaan_Jurusan_Teknik_Informatika_leo1iw.jpg",
    tags: ["teknikinformatika", "it", "prospek", "informatika", "pekerjaan", "teknologi"],
    description:
      "The Informatics Engineering Department is one of the departments that has promising job prospects in the future. This is due to increasingly rapid technological developments and the large need for experts in the field of information technology.",
  },
  {
    _id: 3,
    title: "Get to know what Redux is, how it works & its advantages",
    path: "mengenal-redux",
    date: "25 September 2022",
    img: "https://res.cloudinary.com/dh6s3dche/image/upload/v1680156651/Blog%20MSN/REDUX_d0qd51.jpg",
    tags: ["redux", "react-redux"],
    description:
      "Redux is an open source JavaScript library used to manage state or data in complex web applications. Redux is designed to be used in conjunction with React, but can also be used with other JavaScript frameworks such as Angular or Vue.",
  },
  {
    _id: 4,
    title: "The Promise and Potential of 5G Technology",
    path: "teknologi-5g",
    date: "06 November 2022",
    img: "https://res.cloudinary.com/dh6s3dche/image/upload/v1680158117/Blog%20MSN/teknologi-5g_w9c16l.jpg",
    tags: ["teknologi-5g", "5g", "redux", "jaringan", "teknologi"],
    description:
      "5G cellular technology is the latest generation of cellular network technology. 5G promises faster download and upload speeds, lower latency, and more reliable connections. In this blog, we will discuss the potential of 5G technology as well as the challenges that need to be overcome.",
  },
  {
    _id: 5,
    title: "5 Latest Technologies That Will Change the Way We Live",
    path: "teknologi-terbaru",
    date: "09 November 2022",
    img: "https://res.cloudinary.com/dh6s3dche/image/upload/v1680159590/Blog%20MSN/5_Teknologi_Terbaru_yang_Akan_Mengubah_Cara_Kita_Hidup_h4qzjc.jpg",
    tags: ["teknologi-terbaru", "teknologi", "teknologi", "iot", "ai", "ar", "blockchain", "quantum-computing"],
    description:
      "Technology continues to develop rapidly and has a major impact on our lives. There are several new technologies that will change the way we live in the future. Here are 5 of the latest technologies that will change the way we live.",
  },
   
];

export default blogs;
