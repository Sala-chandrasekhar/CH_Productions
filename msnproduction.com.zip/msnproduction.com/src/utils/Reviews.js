const Reviews = [
  {
    id: 1,
    name: "Amar",
    bio: "CEO",
    img: "https://i.ibb.co/r53shNs/pratama-budiaji.jpg",
    description:
      "Amazingly fast website work, good resolution, good speed. Thank you, CH PRODUCTION really recommended😊",
  },
  {
    id: 2,
    name: "Prasanth",
    bio: "Fruit Ice Entrepreneur",
    img: "https://i.ibb.co/mJJ8sm1/bapak-kurniawan.jpg",
    description:
      "I have checked the website really well, the best service recommended by friends is not wrong. The advertising is also good, there are already 7 customer prospects👍👍",
  },
  {
    id: 3,
    name: "Tharun",
    bio: "Bride and Groom",
    img: "https://i.ibb.co/dgLRQZw/mempelai-1.jpg",
    description:
      "We are very happy with the work of the invitation website which is very fast and efficient and the website is really great and highly recommended 🥰😍😍",
  },
  {
    id: 4,
    name: "Sateesh",
    bio: "Founder of Metro",
    img: "https://i.ibb.co/FVnbpjM/ibu-silvana.jpg",
    description:
      "It's really awesome and cool, since using Google Ads my business sales and profits have met the targets I wanted, the best thing is all 👌😁",
  },
];

export default Reviews;
